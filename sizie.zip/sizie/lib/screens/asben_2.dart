import 'package:flutter/material.dart';

class AbsenExcel extends StatelessWidget {
  const AbsenExcel({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF4B6584),
      extendBodyBehindAppBar: true,

      // =========================== HEADER ===========================
      body: Column(
        children: [
          Container(
            height: 135,
            decoration: const BoxDecoration(
              color: Color(0xFF4B6584),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(35),
                bottomRight: Radius.circular(35),
              ),
            ),
            child: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              toolbarHeight: 130,
              automaticallyImplyLeading: false,
              title: const Row(
                children: [
                  // Foto Profile Icon
                  CircleAvatar(
                    radius: 23,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.person, size: 30, color: Color(0xFF4B6584)),
                  ),
                  SizedBox(width: 12),

                  // Nama & Role
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Jihol Rafzan',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                        ),
                      ),
                      Text(
                        'WALI KELAS / XII PPLG RPL 2',
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              actions: [
                Padding(
                  padding: const EdgeInsets.only(right: 15.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.logout, color: Colors.white),
                      SizedBox(height: 3),
                      Text(
                        "Keluar",
                        style: TextStyle(color: Colors.white, fontSize: 11),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),

          // ========================= BODY ==========================
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(35),
                  topRight: Radius.circular(35),
                ),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(18),
                child: Column(
                  children: [
                    // ------------------- KARTU 2 KOLOM -------------------
                    Row(
                      children: [
                        Expanded(
                          child: _menuCard(
                            icon: Icons.edit,
                            text: "ABSEN SISWA",
                          ),
                        ),
                        const SizedBox(width: 15),
                        Expanded(
                          child: _menuCard(
                            icon: Icons.history,
                            text: "RIWAYAT ABSEN",
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 18),

                    // -------------------- EXPORT -------------------------
                    Container(
                      height: 110,
                      decoration: BoxDecoration(
                        color: const Color(0xFF4B8A58),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            spreadRadius: 1,
                            blurRadius: 6,
                          )
                        ],
                      ),
                      child: Row(
                        children: [
                          const SizedBox(width: 20),
                          const Expanded(
                            child: Text(
                              "EXPORT TO EXCEL",
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(right: 18),
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Colors.white30,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.arrow_forward_ios,
                                color: Colors.white),
                          )
                        ],
                      ),
                    ),

                    const SizedBox(height: 60),

                    // --------------------- GALERI ------------------------
                    SizedBox(
                      height: 110,
                      child: Row(
                        children: [
                          Expanded(
                            child: _imageBox("assets/images/frame3.jpg"),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _imageBox("assets/images/frame2.jpg"),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),

      // ======================= BOTTOM NAV =========================
      bottomNavigationBar: _bottomNav(),
    );
  }

  // =================================================================
  //  🔷 CARD MENU UTAMA
  // =================================================================
  Widget _menuCard({required IconData icon, required String text}) {
    return Container(
      height: 120,
      decoration: BoxDecoration(
        color: const Color(0xFF4B6584),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            spreadRadius: 1,
            blurRadius: 6,
          )
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white, size: 40),
          const SizedBox(height: 10),
          Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  // =================================================================
  //  📸 FRAME GAMBAR
  // =================================================================
  Widget _imageBox(String path) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.asset(
        path,
        fit: BoxFit.cover,
        errorBuilder: (c, e, s) => Container(
          color: Colors.grey[300],
          child: const Center(
            child: Text(
              "Missing\nImage",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12),
            ),
          ),
        ),
      ),
    );
  }

  // =================================================================
  //  🔘 BOTTOM NAVIGATION
  // =================================================================
  Widget _bottomNav() {
    return Container(
      height: 75,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.15),
              blurRadius: 8,
              spreadRadius: 1)
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: const [
              _navItem(Icons.list, "LIST SISWA"),
              SizedBox(width: 60),
              _navItem(Icons.person, "GURU SISWA"),
            ],
          ),

          // HOME BULAT DI TENGAH
          Positioned(
            bottom: 10,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: const Padding(
                padding: EdgeInsets.all(5),
                child: CircleAvatar(
                  radius: 30,
                  backgroundColor: Color(0xFF4B6584),
                  child: Icon(Icons.home, color: Colors.white, size: 32),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =================================================================
//  🔹 NAV ITEM
// =================================================================
class _navItem extends StatelessWidget {
  final IconData icon;
  final String label;

  const _navItem(this.icon, this.label);

  @override
  Widget build(BuildContext context) {
    const activeColor = Color(0xFF4B6584);

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 25, color: activeColor),
        Text(
          label,
          style: TextStyle(
            color: activeColor,
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}

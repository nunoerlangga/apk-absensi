import 'package:flutter/material.dart';

// Ganti URL menjadi path lokal asset
const String backgroundPatternAsset = 'assets/images/bg_pattern.png';

// Warna Biru Tua yang digunakan pada gambar
const Color _kDarkBlue = Color(0xFF4B6584);
// Warna Kuning/Emas untuk tombol
const Color _kGoldenYellow = Color(0xFFFCC034);

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  LoginState createState() => LoginState();
}

class LoginState extends State<Login> {
  Widget _buildLoginCard(BuildContext context) {
    return Card(
      elevation: 10,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(30),
      ),
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const TextField(
              decoration: InputDecoration(
                labelText: 'Username',
                labelStyle: TextStyle(color: Colors.grey),
                floatingLabelBehavior: FloatingLabelBehavior.always,
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFDDDDDD), width: 1.0),
                ),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFDDDDDD), width: 1.0),
                ),
              ),
            ),
            const SizedBox(height: 25),

            const TextField(
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: TextStyle(color: Colors.grey),
                floatingLabelBehavior: FloatingLabelBehavior.always,
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFDDDDDD), width: 1.0),
                ),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Color(0xFFDDDDDD), width: 1.0),
                ),
              ),
            ),
            const SizedBox(height: 40),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  print('Tombol MASUK ditekan');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: _kGoldenYellow,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                  elevation: 0,
                ),
                child: const Text(
                  'MASUK',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    const cardHorizontalPadding = 40.0;
    const cardApproxHeight = 360.0;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: _kDarkBlue,
        elevation: 0,
        centerTitle: true,
        
        title: Padding(
          padding: const EdgeInsets.only(top: 20.0, bottom: 20.0),
          child: const Text(
            'LOGIN AKUN',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),

      body: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                flex: 55,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    image: DecorationImage(
                      image: AssetImage(backgroundPatternAsset),
                      fit: BoxFit.cover,
                      colorFilter: ColorFilter.mode(
                        const Color.fromARGB(255, 255, 255, 255).withOpacity(0.5),
                        BlendMode.dstATop,
                      ),
                    ),
                  ),
                  
                ),
              ),

              const Expanded(
                flex: 45,
                child: SizedBox(
                  width: double.infinity,
                  child: DecoratedBox(
                    decoration: BoxDecoration(color: _kDarkBlue),
                  ),
                ),
              ),
            ],
          ),

          Positioned(
            top: (screenHeight * 0.55) - (cardApproxHeight * 0.4),
            left: cardHorizontalPadding,
            right: cardHorizontalPadding,
            child: SingleChildScrollView(
              child: _buildLoginCard(context),
            ),
          ),
        ],
      ),
    );
  }
}

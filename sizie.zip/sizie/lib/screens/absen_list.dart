import 'package:flutter/material.dart';
import 'dart:math';

/// Path file screenshot yang kamu upload (tooling akan konversi jadi URL jika perlu)
const String screenshotUrl = '/mnt/data/c771f16d-b6ed-479e-a827-c59d364261d5.png';

enum AbsenStatus { none, sakit, izin, alfa }

class AbsenList extends StatefulWidget {
  const AbsenList({super.key});

  @override
  State<AbsenList> createState() => _AbsenListState();
}

class _AbsenListState extends State<AbsenList> {
  // contoh data siswa
  final List<Map<String, dynamic>> _students = List.generate(12, (index) {
    final names = [
      'Egi Naga',
      'Egiana',
      'Egi Perong',
      'Egi Rasyid',
      'Egi Sambo',
      'Egi Rafzan',
      'Egi Putra',
      'Egi Budi',
      'Egi Sulaiman',
      'Egi Kurnia',
      'Egi Wardana',
      'Egi Haris'
    ];
    final genders = [
      'Laki - Laki',
      'Perempuan',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki',
      'Laki - Laki'
    ];
    return {
      'id': index + 1,
      'name': names[index % names.length],
      'gender': genders[index % genders.length],
      'status': AbsenStatus.none,
    };
  });

  String _query = '';

  List<Map<String, dynamic>> get _filteredStudents {
    if (_query.trim().isEmpty) return _students;
    final q = _query.toLowerCase();
    return _students
        .where((s) => s['name'].toString().toLowerCase().contains(q))
        .toList();
  }

  void _setStatus(int studentIndex, AbsenStatus status) {
    setState(() {
      final current = _students[studentIndex]['status'] as AbsenStatus;
      // Jika mengetap status yang sama => nonaktifkan (toggle)
      if (current == status) {
        _students[studentIndex]['status'] = AbsenStatus.none;
      } else {
        // radio-like: set ke status terpilih
        _students[studentIndex]['status'] = status;
      }
    });
  }

  Color _statusColor(AbsenStatus s) {
    switch (s) {
      case AbsenStatus.sakit:
        return const Color(0xFFFFF176); // kuning (lebih lembut)
      case AbsenStatus.izin:
        return const Color(0xFFFFB74D); // oren
      case AbsenStatus.alfa:
        return const Color(0xFFEF5350); // merah
      case AbsenStatus.none:
      default:
        return Colors.grey.shade200;
    }
  }

  Widget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      toolbarHeight: 120,
      automaticallyImplyLeading: false,
      title: const Row(
        children: [
          Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
          SizedBox(width: 8),
          Text(
            'XII PPLG RPL 2',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              letterSpacing: 0.6,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _searchField() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(
          children: [
            const Icon(Icons.search, color: Colors.grey),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                onChanged: (v) => setState(() => _query = v),
                decoration: const InputDecoration(
                  hintText: 'Search',
                  border: InputBorder.none,
                  isDense: true,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tableHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12),
      child: Row(
        children: [
          SizedBox(
            width: 36,
            child: Text(
              'No',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Nama',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
            ),
          ),
          SizedBox(
            width: 120,
            child: Text(
              'Keterangan',
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
            ),
          )
        ],
      ),
    );
  }

  Widget _studentCard(int realIndex, Map<String, dynamic> student) {
    // realIndex: index di _students
    final status = student['status'] as AbsenStatus;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 6),
      child: Material(
        color: Colors.white,
        elevation: 3,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Nomor (1., 2., ...)
              SizedBox(
                width: 36,
                child: Text(
                  '${student['id']}.',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(width: 8),

              // Nama & Kelamin
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      student['name'],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      student['gender'],
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    )
                  ],
                ),
              ),

              // Tombol S I A
              Row(
                children: [
                  _smallStatusButton(
                    label: 'S',
                    title: 'Sakit',
                    isActive: status == AbsenStatus.sakit,
                    color: const Color(0xFFFFF176),
                    onTap: () => _setStatus(realIndex, AbsenStatus.sakit),
                  ),
                  const SizedBox(width: 8),
                  _smallStatusButton(
                    label: 'I',
                    title: 'Izin',
                    isActive: status == AbsenStatus.izin,
                    color: const Color(0xFFFFB74D),
                    onTap: () => _setStatus(realIndex, AbsenStatus.izin),
                  ),
                  const SizedBox(width: 8),
                  _smallStatusButton(
                    label: 'A',
                    title: 'Alfa',
                    isActive: status == AbsenStatus.alfa,
                    color: const Color(0xFFEF5350),
                    onTap: () => _setStatus(realIndex, AbsenStatus.alfa),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _smallStatusButton({
    required String label,
    required String title,
    required bool isActive,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 34,
        height: 28,
        decoration: BoxDecoration(
          color: isActive ? color : Colors.white,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: isActive ? color.withOpacity(0.0) : Colors.grey.shade300,
            width: 1,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.12),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  )
                ]
              : null,
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 12,
            color: isActive ? Colors.white : Colors.black,
          ),
        ),
      ),
    );
  }

  Widget _bottomNav() {
    const activeColor = Color(0xFF4B6584);
    return Container(
      height: 70,
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 8)],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: const [
              _navItem(Icons.list, "LIST SISWA"),
              SizedBox(width: 60),
              _navItem(Icons.person, "GURU SISWA"),
            ],
          ),
          Positioned(
            bottom: 8,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 10)],
              ),
              child: const Padding(
                padding: EdgeInsets.all(6.0),
                child: CircleAvatar(
                  radius: 26,
                  backgroundColor: activeColor,
                  child: Icon(Icons.home, color: Colors.white, size: 30),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // warna dasar header
    const headerBlue = Color(0xFF4B6584);

    return Scaffold(
      backgroundColor: headerBlue,
      extendBodyBehindAppBar: true,
      // Header
      body: Column(
        children: [
          Container(
            height: 170,
            decoration: const BoxDecoration(
              color: headerBlue,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(26),
                bottomRight: Radius.circular(26),
              ),
            ),
            child: SafeArea(
              bottom: false,
              child: Column(
                children: [
                  _buildAppBar(),
                  const SizedBox(height: 6),
                  _searchField(),
                  const SizedBox(height: 8),
                  _tableHeader(),
                ],
              ),
            ),
          ),

          // Body white card list
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(26), topRight: Radius.circular(26)),
              ),
              child: ListView.builder(
                padding: const EdgeInsets.only(top: 16, bottom: 90),
                itemCount: _filteredStudents.length,
                itemBuilder: (context, idx) {
                  // find real index in original _students list
                  final student = _filteredStudents[idx];
                  final realIndex = _students.indexWhere((s) => s['id'] == student['id']);
                  return _studentCard(realIndex, student);
                },
              ),
            ),
          ),
        ],
      ),

      bottomNavigationBar: _bottomNav(),
      // optional floatingActionButton: null,
    );
  }
}

/// Simple nav item widget
class _navItem extends StatelessWidget {
  final IconData icon;
  final String label;
  const _navItem(this.icon, this.label, {super.key});

  @override
  Widget build(BuildContext context) {
    const activeColor = Color(0xFF4B6584);
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 24, color: activeColor),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: activeColor, fontSize: 11))
      ],
    );
  }
}

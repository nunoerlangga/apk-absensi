import 'package:flutter/material.dart';

// --- MAIN WIDGET ---
class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  final Color _darkBlue = const Color(0xFF3E5974);
  final Color _white = const Color(0xFFFFFFFF);
  final Color _buttonColor = const Color(0xFFFFC740);

  @override
  Widget build(BuildContext context) {
    // Tampilan awal adalah Splash Screen.
    // Anda bisa mengganti tampilan ini dengan LoginScreen atau HomeScreen
    // jika Anda ingin menguji halaman lain secara langsung.
    return _buildSplashScreen(context);
  }

  // --- 1. SPLASH SCREEN (iPhone 16 Pro - 1.jpg) ---
  Widget _buildSplashScreen(BuildContext context) {
    return Scaffold(
      backgroundColor: _white,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final screenWidth = constraints.maxWidth;
          final screenHeight = constraints.maxHeight;

          return Stack(
            children: [
              // Latar Belakang Pola (Diganti dengan ikon standar karena tidak ada file asset)
              Positioned.fill(
                child: Center(
                  child: Wrap(
                    spacing: 40,
                    runSpacing: 40,
                    children: [
                      for (int i = 0; i < 20; i++) 
                      Image.asset('assets/images/bg_pattern.png'),
                    ],
                  ),
                ),
              ),
              
              // DEKORASI BIRU TUA (Garis-garis & Lingkaran) - Responsif
              // Kiri Atas - Garis Miring
              Positioned(
                top: screenHeight * -0.05,
                left: screenWidth * -0.15,
                child: Transform.rotate(
                  angle: -0.4,
                  child: Container(
                    width: screenWidth * 0.8,
                    height: screenHeight * 0.3,
                    decoration: BoxDecoration(
                      color: _darkBlue.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),
              ),
              // Kanan Bawah - Garis Miring
              Positioned(
                bottom: screenHeight * -0.05,
                right: screenWidth * -0.15,
                child: Transform.rotate(
                  angle: -0.4,
                  child: Container(
                    width: screenWidth * 0.8,
                    height: screenHeight * 0.3,
                    decoration: BoxDecoration(
                      color: _darkBlue.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),
              ),
              // Lingkaran Besar Kiri Bawah
              Positioned(
                bottom: screenHeight * 0.25,
                left: screenWidth * -0.1,
                child: Container(
                  width: screenWidth * 0.25,
                  height: screenWidth * 0.25,
                  decoration: BoxDecoration(color: _darkBlue.withOpacity(0.9), shape: BoxShape.circle),
                ),
              ),
              // Lingkaran Besar Kanan Atas
              Positioned(
                top: screenHeight * 0.2,
                right: screenWidth * -0.1,
                child: Container(
                  width: screenWidth * 0.25,
                  height: screenWidth * 0.25,
                  decoration: BoxDecoration(color: _darkBlue.withOpacity(0.9), shape: BoxShape.circle),
                ),
              ),

              // Konten Teks SIZIE
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "WELCOME TO",
                      style: TextStyle(
                        color: Color(0xFF3E5974),
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                    SizedBox(height: screenHeight * 0.01),
                    Text(
                      "SIZIE",
                      style: TextStyle(
                        color: const Color(0xFF3D3B3B),
                        fontSize: screenHeight * 0.1, // Font size responsif
                        fontWeight: FontWeight.w900,
                        height: 1.0,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
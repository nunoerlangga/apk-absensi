import 'package:flutter/material.dart';

void main() {
  runApp(const Absen());
}

class Absen extends StatelessWidget {
  const Absen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sizie Absensi',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF4B6584), // Biru tua
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const AbsenScreen(),
    );
  }
}

// =================================================================
// 1. CUSTOM WIDGETS (CARDS)
// =================================================================

/// Card Kustom untuk Aksi (Absen Siswa & Riwayat Absen)
class ActionCard extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;

  const ActionCard({
    Key? key,
    required this.icon,
    required this.text,
    required this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: InkWell(
        onTap: () {},
        borderRadius: BorderRadius.circular(15),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white, size: 40),
              const SizedBox(height: 10),
              Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Card Kustom untuk Jumlah Ketidakhadiran (Sakit, Izin, Alfa)
class CountCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final int count;
  final Color color;

  const CountCard({
    Key? key,
    required this.icon,
    required this.label,
    required this.count,
    required this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Icon di kiri
            Icon(icon, color: Colors.white, size: 30),
            // Label dan Jumlah di kanan
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    '$count',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =================================================================
// 2. MAIN SCREEN CLASS (AbsenScreen)
// =================================================================

class AbsenScreen extends StatelessWidget {
  const AbsenScreen({super.key});

  /// Bagian Header/AppBar
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Colors.transparent,
      elevation: 0,
      toolbarHeight: 90,
      title: const Row(
        children: [
          Icon(Icons.person, size: 40, color: Colors.white),
          SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Nuno Erlangga',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              Text(
                'SEKRETARIS / XII PPLG RPL 2',
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
        ],
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 15.0),
          child: TextButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.exit_to_app, color: Colors.white),
            label: const Text('Keluar', style: TextStyle(color: Colors.white)),
          ),
        ),
      ],
    );
  }

  /// Bagian Bottom Navigation Bar
  Widget _buildBottomNavBar() {
    Widget buildNavBarItem(IconData icon, String label) {
        final color = (label == 'LIST SISWA' || label == 'GURU SISWA')
          ? const Color(0xFF4B6584) // use app blue for these two items
          : Colors.grey;

      return InkWell(
        onTap: () {},
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 24),
            Text(label, style: TextStyle(color: color, fontSize: 10)),
          ],
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
          ),
        ],
      ),
      height: 70,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              buildNavBarItem(Icons.list, 'LIST SISWA'),
              const SizedBox(width: 60),
              buildNavBarItem(Icons.person, 'GURU SISWA'),
            ],
          ),
          // Tombol HOME besar (FAB Style)
          Positioned(
            bottom: 5,
            child: InkWell(
              onTap: () {},
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Padding(
                  padding: EdgeInsets.all(3.0),
                  child: CircleAvatar(
                    radius: 30,
                    backgroundColor: Color(0xFF4B6584), // Warna biru tua
                    child: Icon(Icons.home, color: Colors.white, size: 35),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Bagian Tengah (Card Absensi dan Galeri)
  Widget _buildBodyContent(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Grid View untuk Kartu Absensi
          GridView.count(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap:
                true, // WAJIB untuk GridView di dalam SingleChildScrollView
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            // childAspectRatio yang responsif
            childAspectRatio:
                MediaQuery.of(context).size.width /
                (MediaQuery.of(context).size.height / 1.5),
            children: <Widget>[
              // Kiri Atas: Absen Siswa
              const ActionCard(
                icon: Icons.edit,
                text: 'ABSEN SISWA',
                color: Color(0xFF4B6584), // Biru tua
              ),
              // Kanan Atas: Jumlah Sakit
              const CountCard(
                icon: Icons.add,
                label: 'JUMLAH SAKIT',
                count: 6,
                color: Color(0xFFDCDD54), // Kuning-hijau
              ),
              // Kiri Bawah: Riwayat Absen
              const ActionCard(
                icon: Icons.history,
                text: 'RIWAYAT ABSEN',
                color: Color(0xFF4B6584), // Biru tua
              ),
              // Kanan Bawah: Izin dan Alfa
              Column(
                children: const [
                  Expanded(
                    child: CountCard(
                      icon: Icons.chat_bubble_outline,
                      label: 'JUMLAH IZIN',
                      count: 2,
                      color: Color(0xFFFF9800), // Orange
                    ),
                  ),
                  SizedBox(height: 10),
                  Expanded(
                    child: CountCard(
                      icon: Icons.close,
                      label: 'JUMLAH ALFA',
                      count: 8,
                      color: Color(0xFFF44336), // Merah
                    ),
                  ),
                ],
              ),
            ],
          ),
          
          const SizedBox(height: 50),
        

          // Bagian Galeri/Gambar
          SizedBox(
            height: 120,
            child: Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(
                      'assets/images/frame3.jpg', // GANTI dengan path yang valid
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: Colors.grey[300],
                        child: const Center(
                          child: Text(
                            'Gambar 1\n(Missing Asset)',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 12),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(
                      'assets/images/frame2.jpg', // GANTI dengan path yang valid
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: Colors.grey[300],
                        child: const Center(
                          child: Text(
                            'Gambar 2\n(Missing Asset)',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 12),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF4B6584),
      extendBodyBehindAppBar: true,

      body: Column(
        children: [
          // Bagian Header (Warna Biru tua)
          Container(
            height: 100,
            decoration: const BoxDecoration(
              color: Color(0xFF4B6584),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: _buildAppBar(),
          ),

          // Bagian Body yang dapat di-scroll
          Expanded(
            child: Container(
              decoration: const BoxDecoration(
                color: Color(0xFFFFFFFF), // Warna background putih
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.only(top: 20, bottom: 20),
                  child: _buildBodyContent(context),
                ),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }
}

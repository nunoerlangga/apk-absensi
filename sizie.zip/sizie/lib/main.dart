import 'package:flutter/material.dart';
import 'package:sizie/screens/absen.dart';
import 'package:sizie/screens/asben_2.dart';
import 'package:sizie/screens/login.dart';
import 'screens/welcome.dart'; 

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false, 
      home: AbsenExcel(),
    );
  }
}

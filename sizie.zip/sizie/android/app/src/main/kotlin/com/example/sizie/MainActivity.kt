package com.example.sizie

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
